// UniVault — small progressive-enhancement helpers (no framework needed).

document.addEventListener('DOMContentLoaded', function () {
  // User menu dropdown
  var userBtn = document.querySelector('.nav-user-btn');
  var dropdown = document.querySelector('.nav-dropdown');
  if (userBtn && dropdown) {
    userBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      dropdown.classList.toggle('open');
    });
    document.addEventListener('click', function () {
      dropdown.classList.remove('open');
    });
  }

  // Mobile nav toggle
  var navToggle = document.querySelector('.nav-toggle');
  var navLinks = document.querySelector('.nav-links');
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', function () {
      navLinks.classList.toggle('open-mobile');
      navLinks.style.display = navLinks.classList.contains('open-mobile') ? 'flex' : '';
    });
  }

  // "Extra feature": dark mode toggle, remembered between visits.
  var themeToggle = document.getElementById('theme-toggle');
  if (themeToggle) {
    themeToggle.addEventListener('click', function () {
      var isDark = document.documentElement.getAttribute('data-theme') === 'dark';
      if (isDark) {
        document.documentElement.removeAttribute('data-theme');
        localStorage.setItem('univault-theme', 'light');
      } else {
        document.documentElement.setAttribute('data-theme', 'dark');
        localStorage.setItem('univault-theme', 'dark');
      }
    });
  }

  // Bookmark toggle via fetch, falls back to normal link if JS fails
  document.querySelectorAll('.bookmark-btn[data-url]').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      var url = btn.getAttribute('data-url');
      var csrftoken = document.querySelector('input[name=csrfmiddlewaretoken]').value;
      fetch(url, {
        method: 'POST',
        headers: {
          'X-Requested-With': 'XMLHttpRequest',
          'X-CSRFToken': csrftoken,
        },
      })
        .then(function (res) { return res.json(); })
        .then(function (data) {
          btn.classList.toggle('active', data.bookmarked);
          btn.querySelector('.bookmark-label').textContent = data.bookmarked ? 'Bookmarked' : 'Bookmark';
        })
        .catch(function () { window.location.href = url; });
    });
  });

  // Auto-dismiss alerts after a few seconds
  document.querySelectorAll('.alert').forEach(function (alert) {
    setTimeout(function () {
      alert.style.transition = 'opacity 0.4s ease';
      alert.style.opacity = '0';
      setTimeout(function () { alert.remove(); }, 400);
    }, 5000);
  });
});
