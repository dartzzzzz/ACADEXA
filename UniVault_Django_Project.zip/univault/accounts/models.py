from django.contrib.auth.models import AbstractUser
from django.db import models
from django.urls import reverse

# Shared academic choices — imported by the resources app too, so a
# student's branch and a resource's branch always use the same vocabulary.
BRANCH_CHOICES = [
    ('CSE', 'Computer Science & Engineering'),
    ('IT', 'Information Technology'),
    ('ECE', 'Electronics & Communication'),
    ('EEE', 'Electrical & Electronics'),
    ('ME', 'Mechanical Engineering'),
    ('CE', 'Civil Engineering'),
    ('MBA', 'Management'),
    ('OTHER', 'Other'),
]

YEAR_CHOICES = [
    (1, '1st Year'),
    (2, '2nd Year'),
    (3, '3rd Year'),
    (4, '4th Year'),
]


class User(AbstractUser):
    """
    Extends Django's built-in user with the academic details UniVault
    needs to tag and filter shared resources: college, branch and year.
    """
    college = models.CharField(max_length=150, blank=True)
    branch = models.CharField(max_length=10, choices=BRANCH_CHOICES, blank=True)
    year = models.PositiveSmallIntegerField(choices=YEAR_CHOICES, null=True, blank=True)
    bio = models.CharField(max_length=280, blank=True, help_text='A short line about yourself.')
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)

    def __str__(self):
        return self.get_full_name() or self.username

    def get_absolute_url(self):
        return reverse('accounts:public_profile', kwargs={'username': self.username})

    @property
    def display_name(self):
        return self.get_full_name() or self.username
