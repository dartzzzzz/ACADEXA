from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

from .models import User


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    fieldsets = BaseUserAdmin.fieldsets + (
        ('Academic details', {'fields': ('college', 'branch', 'year', 'bio', 'avatar')}),
    )
    list_display = ['username', 'email', 'college', 'branch', 'year', 'is_staff', 'date_joined']
    list_filter = BaseUserAdmin.list_filter + ('branch', 'year')
    search_fields = ['username', 'email', 'first_name', 'last_name', 'college']
