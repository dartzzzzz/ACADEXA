from django import forms
from django.contrib.auth.forms import UserCreationForm

from .models import User

TEXT_WIDGET_CLASS = 'field'


class RegisterForm(UserCreationForm):
    """Sign-up form: adds academic details on top of Django's default fields."""

    email = forms.EmailField(required=True, help_text='Use your college email if you have one.')
    first_name = forms.CharField(max_length=30, required=True, label='First name')
    last_name = forms.CharField(max_length=30, required=False, label='Last name')

    class Meta:
        model = User
        fields = [
            'username', 'first_name', 'last_name', 'email',
            'college', 'branch', 'year', 'password1', 'password2',
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            field.widget.attrs['class'] = TEXT_WIDGET_CLASS
        self.fields['college'].widget.attrs['placeholder'] = 'e.g. Sharda University'

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
        return user


class ProfileUpdateForm(forms.ModelForm):
    """Lets a student update their academic details, bio and avatar."""

    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email', 'college', 'branch', 'year', 'bio', 'avatar']
        widgets = {
            'bio': forms.Textarea(attrs={'rows': 3, 'maxlength': 280}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            if name != 'avatar':
                field.widget.attrs['class'] = TEXT_WIDGET_CLASS
