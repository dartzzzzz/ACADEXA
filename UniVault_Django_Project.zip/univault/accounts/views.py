from django.contrib import messages
from django.contrib.auth import login, get_user_model
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView, LogoutView
from django.shortcuts import get_object_or_404, redirect, render

from resources.models import Resource
from .forms import ProfileUpdateForm, RegisterForm

User = get_user_model()


def register(request):
    """Create an account and sign the student straight in."""
    if request.user.is_authenticated:
        return redirect('resources:home')

    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, f'Welcome to UniVault, {user.display_name}. Your account is ready.')
            return redirect('resources:home')
    else:
        form = RegisterForm()

    return render(request, 'accounts/register.html', {'form': form})


class CustomLoginView(LoginView):
    template_name = 'accounts/login.html'
    redirect_authenticated_user = True


class CustomLogoutView(LogoutView):
    next_page = 'resources:home'


@login_required
def profile(request):
    """The signed-in student's own profile, editable."""
    resources = Resource.objects.filter(uploaded_by=request.user).order_by('-uploaded_at')
    return render(request, 'accounts/profile.html', {
        'profile_user': request.user,
        'resources': resources,
        'is_own_profile': True,
    })


def public_profile(request, username):
    """Any student's public profile — what they've contributed to UniVault."""
    user_obj = get_object_or_404(User, username=username)
    resources = Resource.objects.filter(uploaded_by=user_obj).order_by('-uploaded_at')
    return render(request, 'accounts/profile.html', {
        'profile_user': user_obj,
        'resources': resources,
        'is_own_profile': request.user.is_authenticated and request.user == user_obj,
    })


@login_required
def edit_profile(request):
    if request.method == 'POST':
        form = ProfileUpdateForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Your profile has been updated.')
            return redirect('accounts:profile')
    else:
        form = ProfileUpdateForm(instance=request.user)

    return render(request, 'accounts/edit_profile.html', {'form': form})
