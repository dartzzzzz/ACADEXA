# UniVault — Centralised Academic Resource-Sharing Platform

UniVault is a full-stack web app where university students upload and
discover notes, previous year question papers, lab manuals, assignments
and e-books — organised by branch, semester, subject and category, with
ratings, bookmarks and a contributor leaderboard.

**Stack:** Python, Django 5, SQLite, server-rendered HTML/CSS/JavaScript
(no frontend framework required).

---

## 1. Setup

```bash
# 1. Create and activate a virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Apply database migrations
python manage.py migrate

# 4. Load demo data (categories, students, an admin account, sample resources)
python manage.py seed_data

# 5. Run the development server
python manage.py runserver
```

Visit **http://127.0.0.1:8000/**.

### Demo logins (created by `seed_data`)

| Role    | Username    | Password      |
|---------|-------------|---------------|
| Student | `demo`      | `demo12345`   |
| Student | `rahul_it`  | `demo12345`   |
| Student | `sneha_ece` | `demo12345`   |
| Admin   | `admin`     | `admin12345`  |

Visit `/admin/` with the admin account to moderate resources, feature a
resource on the homepage, or manage users.

> These credentials are for local demo/evaluation use only. If you ever
> deploy this beyond your own machine, change `SECRET_KEY` in
> `univault/settings.py`, set `DEBUG = False`, and rotate every password.

---

## 2. Core features

- **Accounts** — sign up with branch/year/college, log in/out, edit your profile and avatar, view any student's public profile.
- **Upload & manage resources** — title, description, subject, branch, semester, category and a file (PDF/Word/PPT/Excel/text/zip, up to 25 MB); owners can edit or delete their own uploads.
- **Browse & search** — full-text search across title/subject/description, with filters for branch, semester and category, and four sort modes (recent, most downloaded, highest rated, title A–Z).
- **Ratings & reviews** — 1–5 star ratings with an optional comment, one per student per resource, with a running average shown everywhere the resource appears.
- **Bookmarks** — save any resource to your dashboard with one click (AJAX, no page reload).
- **Download tracking** — every download increments a counter, powering the "Most downloaded" section.
- **Dashboard** — a student's own uploads (with stats), and their bookmarked resources, in one place.
- **Categories** — colour-tagged types (Notes, Previous Year Papers, Lab Manuals, Assignments, E-Books, Presentations) that double as browsing shortcuts.
- **Django admin** — full moderation panel for users, resources, ratings and bookmarks out of the box.

## 3. Extra features added on top of the core spec

- **Leaderboard** (`/leaderboard/`) — ranks students by resources shared and total downloads earned, to gamify contributing back.
- **Editor's Picks** — admins can flag any resource as `is_featured` in the admin panel; featured resources get a homepage spotlight and a badge everywhere they appear.
- **Top Rated badge** — automatically shown on any resource with an average of 4.5★+ from at least two ratings.
- **Dark mode** — a toggle in the navbar remembers the student's preference (`localStorage`) and re-applies it instantly on the next visit, no flash of the wrong theme.
- **Branch analytics strip** — a dependency-free CSS bar chart on the homepage showing how resources are distributed across branches.

## 4. Suggested future scope (good for a "future work" slide)

- Email/OTP verification tied to a real college domain
- In-app notifications when a bookmarked resource is updated
- A comment/discussion thread under each resource, separate from star ratings
- Basic plagiarism/duplicate-file detection on upload
- A recommendation engine ("students who downloaded this also downloaded…")
- A Progressive Web App (installable, offline-capable) build of the frontend
- REST API + a companion mobile app

## 5. Project structure

```
univault/
├── manage.py
├── requirements.txt
├── db.sqlite3                  # created by migrate; ships pre-seeded here
├── univault/                   # project settings & root URLs
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py / asgi.py
├── accounts/                   # custom User model, auth, profiles
│   ├── models.py                (User, BRANCH_CHOICES, YEAR_CHOICES)
│   ├── forms.py                 (RegisterForm, ProfileUpdateForm)
│   ├── views.py / urls.py / admin.py
│   └── templates/accounts/      (login, register, profile, edit_profile)
├── resources/                  # the core app
│   ├── models.py                (Category, Resource, Rating, Bookmark)
│   ├── forms.py                 (ResourceForm, RatingForm)
│   ├── views.py / urls.py / admin.py
│   ├── management/commands/seed_data.py
│   └── templates/resources/     (home, browse, detail, upload/edit,
│                                  dashboard, leaderboard, category,
│                                  about, delete-confirm, partials/)
├── templates/                  # base.html + shared navbar/footer includes
├── static/
│   ├── css/style.css            (the whole design system, incl. dark mode)
│   └── js/main.js               (nav menu, bookmarks, theme toggle, alerts)
└── media/                       # uploaded files (seed data ships a few)
```

## 6. Data model at a glance

- **User** (extends Django's `AbstractUser`) → college, branch, year, bio, avatar
- **Category** → name, slug, description, colour (drives every tag in the UI)
- **Resource** → title, description, subject, branch, semester, category (FK), file, uploaded_by (FK → User), download_count, is_featured
- **Rating** → resource (FK), user (FK), stars (1–5), comment — unique per (resource, user)
- **Bookmark** → user (FK), resource (FK) — unique per (user, resource)

## 7. Notes for your viva/demo

- `python manage.py seed_data` is idempotent — safe to run again, it skips anything that already exists.
- The rating on the browse page's "Highest rated" sort is computed in Python (not the database) since it depends on a related `Rating` average — fine at this project's scale, but worth mentioning if asked about scaling trade-offs.
- File uploads are validated both client-side (`accept` hints) and server-side (extension whitelist + 25 MB size check in `ResourceForm.clean_file`).
- CSRF protection, `login_required` decorators, and ownership checks (`resource.uploaded_by != request.user`) are used throughout — worth pointing out if your evaluator asks about security.
