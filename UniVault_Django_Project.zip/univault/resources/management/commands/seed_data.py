"""
Populates UniVault with demo categories, a few demo student accounts, an
admin account, and a handful of sample resources — so the project can be
demoed immediately after `migrate` without manually creating data.

Usage:
    python manage.py seed_data
"""
import random

from django.contrib.auth import get_user_model
from django.core.files.base import ContentFile
from django.core.management.base import BaseCommand

from resources.models import Category, Rating, Resource

User = get_user_model()

CATEGORIES = [
    ('Notes', 'Class and self-made notes', '#2A4494'),
    ('Previous Year Papers', 'Solved and unsolved past exam papers', '#E7A93C'),
    ('Lab Manuals', 'Practical files and lab records', '#2E8B57'),
    ('Assignments', 'Sample and solved assignments', '#C1544B'),
    ('E-Books', 'Textbooks and reference material', '#6C4AB6'),
    ('Presentations', 'Slide decks for seminars and vivas', '#1B2340'),
]

# username, first, last, college, branch, year, bio
DEMO_STUDENTS = [
    ('demo', 'Aditi', 'Sharma', 'Demo Institute of Technology', 'CSE', 3, 'Third-year CSE student sharing notes and past papers.'),
    ('rahul_it', 'Rahul', 'Verma', 'Demo Institute of Technology', 'IT', 4, 'Final-year IT student. I mostly upload lab manuals and PYQs.'),
    ('sneha_ece', 'Sneha', 'Iyer', 'Demo Institute of Technology', 'ECE', 2, 'Second-year ECE. Sharing whatever helped me survive semester exams.'),
]

# title, uploader, branch, semester, subject, category, description, featured
DEMO_RESOURCES = [
    ('Data Structures — Unit 3: Trees & Graphs', 'demo', 'CSE', 3, 'Data Structures', 'Notes',
     'Covers binary trees, AVL trees, and graph traversal (BFS/DFS) with worked examples.', True),
    ('Operating Systems Mid-Sem 2023 (Solved)', 'demo', 'CSE', 4, 'Operating Systems', 'Previous Year Papers',
     'Full solutions to the 2023 mid-semester paper, including the scheduling numericals.', True),
    ('DBMS Lab Manual — SQL Joins & Normalization', 'rahul_it', 'IT', 4, 'Database Management Systems', 'Lab Manuals',
     'All ten lab experiments with queries, expected output, and viva questions.', True),
    ('Digital Electronics Assignment 2 (Solved)', 'sneha_ece', 'ECE', 2, 'Digital Electronics', 'Assignments',
     'Karnaugh maps and combinational circuit design problems, worked step by step.', False),
    ('Engineering Thermodynamics — Reference E-Book', 'demo', 'CSE', 3, 'Thermodynamics', 'E-Books',
     'A concise reference covering the laws of thermodynamics with solved numericals.', False),
    ('Machine Learning Seminar Slides', 'demo', 'CSE', 6, 'Machine Learning', 'Presentations',
     'Slide deck introducing supervised vs unsupervised learning, used for a class seminar.', False),
    ('Computer Networks — Unit 5: Routing Protocols', 'rahul_it', 'IT', 5, 'Computer Networks', 'Notes',
     'Distance-vector vs link-state routing, with diagrams of RIP and OSPF in action.', False),
    ('Circuit Theory End-Sem 2022 (Unsolved)', 'sneha_ece', 'ECE', 3, 'Circuit Theory', 'Previous Year Papers',
     'Original question paper for practice, no solutions included.', False),
]

SAMPLE_COMMENTS = [
    (5, 'Exactly what I needed before the exam, very clear.'),
    (4, 'Good notes, could use a couple more diagrams.'),
    (5, 'Saved me hours of writing my own notes. Thank you!'),
    (3, 'Decent but a bit outdated for the current syllabus.'),
]


class Command(BaseCommand):
    help = 'Seed UniVault with demo categories, demo users, an admin account, and sample resources.'

    def handle(self, *args, **options):
        # 1. Categories
        category_objs = {}
        for name, description, color in CATEGORIES:
            category, _ = Category.objects.get_or_create(
                name=name, defaults={'description': description, 'color': color}
            )
            category_objs[name] = category
        self.stdout.write(self.style.SUCCESS(f'✓ {len(category_objs)} categories ready'))

        # 2. Demo student accounts
        student_objs = {}
        for username, first, last, college, branch, year, bio in DEMO_STUDENTS:
            student, created = User.objects.get_or_create(
                username=username,
                defaults=dict(
                    email=f'{username}@univault.edu', first_name=first, last_name=last,
                    college=college, branch=branch, year=year, bio=bio,
                ),
            )
            if created:
                student.set_password('demo12345')
                student.save()
            student_objs[username] = student
        self.stdout.write(self.style.SUCCESS(
            f'✓ {len(student_objs)} demo students ready (password for all: demo12345)'
        ))

        # 3. Admin account for exploring Django admin
        if not User.objects.filter(username='admin').exists():
            admin_user = User.objects.create_superuser(
                username='admin', email='admin@univault.edu', password='admin12345',
            )
            admin_user.first_name = 'UniVault'
            admin_user.last_name = 'Admin'
            admin_user.save()
            self.stdout.write(self.style.SUCCESS('✓ admin account created (username: admin / password: admin12345)'))
        else:
            self.stdout.write('• admin account already exists, skipping')

        # 4. Sample resources with a tiny placeholder text file attached
        created_count = 0
        for title, uploader, branch, semester, subject, category_name, description, featured in DEMO_RESOURCES:
            if Resource.objects.filter(title=title).exists():
                continue
            resource = Resource(
                title=title,
                description=description,
                subject=subject,
                branch=branch,
                semester=semester,
                category=category_objs[category_name],
                uploaded_by=student_objs[uploader],
                download_count=random.randint(3, 140),
                is_featured=featured,
            )
            placeholder_text = (
                f'{title}\n{"=" * len(title)}\n\n{description}\n\n'
                f'-- This is a placeholder file generated by seed_data for demo purposes.\n'
                f'-- Replace it by uploading a real file through the UniVault "Upload" page.\n'
            )
            file_bytes = ContentFile(placeholder_text.encode('utf-8'))
            filename = title.lower().replace(' ', '_').replace('/', '-')[:50] + '.txt'
            resource.file.save(filename, file_bytes, save=False)
            resource.save()
            created_count += 1

            # A couple of sample ratings/comments per resource, from throwaway reviewer accounts
            for i, (stars, comment) in enumerate(random.sample(SAMPLE_COMMENTS, k=2)):
                reviewer, _ = User.objects.get_or_create(
                    username=f'reviewer{i+1}',
                    defaults=dict(email=f'reviewer{i+1}@univault.edu', first_name=f'Reviewer{i+1}'),
                )
                if not reviewer.has_usable_password():
                    reviewer.set_password('reviewer12345')
                    reviewer.save()
                Rating.objects.get_or_create(
                    resource=resource, user=reviewer, defaults={'stars': stars, 'comment': comment}
                )

        self.stdout.write(self.style.SUCCESS(f'✓ {created_count} sample resources created'))
        self.stdout.write(self.style.SUCCESS(
            '\nSeed complete.\n'
            '  Student login  → demo / demo12345  (also rahul_it, sneha_ece)\n'
            '  Admin login    → admin / admin12345  (visit /admin/)'
        ))
