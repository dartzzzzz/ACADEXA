from django.urls import path

from . import views

app_name = 'resources'

urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('browse/', views.resource_list, name='resource_list'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('leaderboard/', views.leaderboard, name='leaderboard'),
    path('category/<slug:slug>/', views.category_detail, name='category_detail'),

    path('resource/upload/', views.resource_create, name='resource_create'),
    path('resource/<int:pk>/', views.resource_detail, name='resource_detail'),
    path('resource/<int:pk>/edit/', views.resource_update, name='resource_update'),
    path('resource/<int:pk>/delete/', views.resource_delete, name='resource_delete'),
    path('resource/<int:pk>/download/', views.resource_download, name='resource_download'),
    path('resource/<int:pk>/bookmark/', views.toggle_bookmark, name='toggle_bookmark'),
    path('resource/<int:pk>/rate/', views.add_rating, name='add_rating'),
]
