from django.conf import settings
from django.core.validators import FileExtensionValidator
from django.db import models
from django.urls import reverse
from django.utils.text import slugify

from accounts.models import BRANCH_CHOICES

SEMESTER_CHOICES = [(i, f'Semester {i}') for i in range(1, 9)]

ALLOWED_EXTENSIONS = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx', 'txt', 'zip']


class Category(models.Model):
    """
    A resource type, e.g. Notes, Previous Year Papers, Lab Manuals.
    Each category carries a colour used as a visual tag throughout the
    site, so students can recognise a resource type at a glance.
    """
    name = models.CharField(max_length=60, unique=True)
    slug = models.SlugField(unique=True, blank=True)
    description = models.CharField(max_length=150, blank=True)
    color = models.CharField(
        max_length=7, default='#2A4494',
        help_text="Hex colour used as this category's tag colour, e.g. #2A4494",
    )

    class Meta:
        verbose_name_plural = 'Categories'
        ordering = ['name']

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('resources:category_detail', kwargs={'slug': self.slug})


def resource_upload_path(instance, filename):
    branch = instance.branch or 'general'
    return f'resources/{branch}/sem{instance.semester}/{filename}'


class Resource(models.Model):
    """A single piece of academic material shared by a student."""

    title = models.CharField(max_length=200)
    description = models.TextField(blank=True, help_text='What does this cover? Any exam tips?')
    subject = models.CharField(max_length=100, help_text='e.g. Data Structures, Thermodynamics')
    branch = models.CharField(max_length=10, choices=BRANCH_CHOICES)
    semester = models.PositiveSmallIntegerField(choices=SEMESTER_CHOICES)
    category = models.ForeignKey(
        Category, on_delete=models.SET_NULL, null=True, related_name='resources',
    )
    file = models.FileField(
        upload_to=resource_upload_path,
        validators=[FileExtensionValidator(allowed_extensions=ALLOWED_EXTENSIONS)],
        help_text='PDF, Word, PowerPoint, Excel, text or a zipped folder — up to 25 MB.',
    )
    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='resources',
    )
    uploaded_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    download_count = models.PositiveIntegerField(default=0)
    # "Extra feature": lets an admin/moderator spotlight standout uploads
    # on the homepage without needing a separate curation model.
    is_featured = models.BooleanField(
        default=False,
        help_text="Show this resource in the homepage's Editor's Picks strip.",
    )

    class Meta:
        ordering = ['-uploaded_at']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('resources:resource_detail', kwargs={'pk': self.pk})

    @property
    def average_rating(self):
        ratings = [r.stars for r in self.ratings.all()]
        return round(sum(ratings) / len(ratings), 1) if ratings else 0

    @property
    def rating_count(self):
        return self.ratings.count()

    @property
    def is_top_rated(self):
        return self.rating_count >= 2 and self.average_rating >= 4.5

    @property
    def file_extension(self):
        return self.file.name.rsplit('.', 1)[-1].upper() if self.file else ''

    @property
    def file_name(self):
        return self.file.name.rsplit('/', 1)[-1] if self.file else ''


class Rating(models.Model):
    """A 1–5 star rating with an optional comment, one per student per resource."""

    resource = models.ForeignKey(Resource, on_delete=models.CASCADE, related_name='ratings')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='ratings')
    stars = models.PositiveSmallIntegerField(choices=[(i, i) for i in range(1, 6)])
    comment = models.TextField(blank=True, max_length=500)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('resource', 'user')
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.user} rated "{self.resource}" {self.stars} stars'


class Bookmark(models.Model):
    """Lets a student save a resource to their dashboard for later."""

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='bookmarks')
    resource = models.ForeignKey(Resource, on_delete=models.CASCADE, related_name='bookmarked_by')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'resource')
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.user} bookmarked "{self.resource}"'
