from django import forms

from .models import Rating, Resource


class ResourceForm(forms.ModelForm):
    class Meta:
        model = Resource
        fields = ['title', 'description', 'subject', 'branch', 'semester', 'category', 'file']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            field.widget.attrs['class'] = 'field'

    def clean_file(self):
        file = self.cleaned_data.get('file')
        if file and file.size > 25 * 1024 * 1024:
            raise forms.ValidationError('That file is larger than 25 MB. Try compressing it first.')
        return file


class RatingForm(forms.ModelForm):
    class Meta:
        model = Rating
        fields = ['stars', 'comment']
        widgets = {
            'stars': forms.RadioSelect(),
            'comment': forms.Textarea(attrs={
                'rows': 2,
                'class': 'field',
                'placeholder': 'Optional — what did you think of this resource?',
            }),
        }
