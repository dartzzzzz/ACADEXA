from django.contrib import admin

from .models import Bookmark, Category, Rating, Resource


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'slug', 'color']
    prepopulated_fields = {'slug': ('name',)}


@admin.register(Resource)
class ResourceAdmin(admin.ModelAdmin):
    list_display = ['title', 'subject', 'branch', 'semester', 'category', 'uploaded_by', 'download_count', 'is_featured', 'uploaded_at']
    list_filter = ['branch', 'semester', 'category', 'is_featured']
    list_editable = ['is_featured']
    search_fields = ['title', 'subject', 'description', 'uploaded_by__username']
    date_hierarchy = 'uploaded_at'


@admin.register(Rating)
class RatingAdmin(admin.ModelAdmin):
    list_display = ['resource', 'user', 'stars', 'created_at']
    list_filter = ['stars']


@admin.register(Bookmark)
class BookmarkAdmin(admin.ModelAdmin):
    list_display = ['user', 'resource', 'created_at']
