from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Count, Q, Sum
from django.http import FileResponse, Http404, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render

from accounts.models import BRANCH_CHOICES
from .forms import RatingForm, ResourceForm
from .models import Bookmark, Category, Rating, Resource, SEMESTER_CHOICES

User = get_user_model()

RESOURCES_PER_PAGE = 9


def home(request):
    recent_resources = Resource.objects.select_related('category', 'uploaded_by')[:6]
    popular_resources = Resource.objects.select_related('category', 'uploaded_by').order_by('-download_count')[:3]
    featured_resources = Resource.objects.filter(is_featured=True).select_related('category', 'uploaded_by')[:3]
    categories = Category.objects.annotate(resource_count=Count('resources')).order_by('name')

    # "Extra feature": a lightweight, dependency-free bar chart of how many
    # resources exist per branch, built with plain CSS widths (no JS charting
    # library needed).
    branch_display = dict(BRANCH_CHOICES)
    branch_stats = list(
        Resource.objects.values('branch').annotate(count=Count('id')).order_by('-count')
    )
    max_branch_count = max((b['count'] for b in branch_stats), default=0)
    for b in branch_stats:
        b['label'] = branch_display.get(b['branch'], b['branch'])
        b['pct'] = round(b['count'] / max_branch_count * 100) if max_branch_count else 0

    context = {
        'recent_resources': recent_resources,
        'popular_resources': popular_resources,
        'featured_resources': featured_resources,
        'categories': categories,
        'branch_stats': branch_stats,
        'total_resources': Resource.objects.count(),
        'total_students': User.objects.count(),
        'total_downloads': sum(Resource.objects.values_list('download_count', flat=True)),
    }
    return render(request, 'resources/home.html', context)


def resource_list(request):
    resources = Resource.objects.select_related('category', 'uploaded_by')

    query = request.GET.get('q', '').strip()
    branch = request.GET.get('branch', '')
    semester = request.GET.get('semester', '')
    category_slug = request.GET.get('category', '')
    sort = request.GET.get('sort', 'recent')

    if query:
        resources = resources.filter(
            Q(title__icontains=query) | Q(subject__icontains=query) | Q(description__icontains=query)
        )
    if branch:
        resources = resources.filter(branch=branch)
    if semester:
        resources = resources.filter(semester=semester)
    if category_slug:
        resources = resources.filter(category__slug=category_slug)

    if sort == 'popular':
        resources = resources.order_by('-download_count')
    elif sort == 'title':
        resources = resources.order_by('title')
    elif sort == 'rating':
        resources = sorted(resources, key=lambda r: r.average_rating, reverse=True)
    else:
        resources = resources.order_by('-uploaded_at')

    paginator = Paginator(resources, RESOURCES_PER_PAGE)
    page_obj = paginator.get_page(request.GET.get('page'))

    # Preserve filters across pagination links
    params = request.GET.copy()
    params.pop('page', None)

    context = {
        'page_obj': page_obj,
        'categories': Category.objects.all(),
        'branch_choices': BRANCH_CHOICES,
        'semester_choices': SEMESTER_CHOICES,
        'query': query,
        'selected_branch': branch,
        'selected_semester': semester,
        'selected_category': category_slug,
        'sort': sort,
        'querystring': params.urlencode(),
        'result_count': paginator.count,
    }
    return render(request, 'resources/resource_list.html', context)


def resource_detail(request, pk):
    resource = get_object_or_404(Resource.objects.select_related('category', 'uploaded_by'), pk=pk)
    ratings = resource.ratings.select_related('user').exclude(comment='')
    user_rating = None
    is_bookmarked = False

    if request.user.is_authenticated:
        user_rating = resource.ratings.filter(user=request.user).first()
        is_bookmarked = Bookmark.objects.filter(user=request.user, resource=resource).exists()

    related_resources = Resource.objects.filter(
        subject__iexact=resource.subject
    ).exclude(pk=resource.pk).select_related('category')[:4]

    context = {
        'resource': resource,
        'ratings': ratings,
        'user_rating': user_rating,
        'is_bookmarked': is_bookmarked,
        'rating_form': RatingForm(instance=user_rating),
        'related_resources': related_resources,
        'star_range': range(1, 6),
    }
    return render(request, 'resources/resource_detail.html', context)


@login_required
def resource_create(request):
    if request.method == 'POST':
        form = ResourceForm(request.POST, request.FILES)
        if form.is_valid():
            resource = form.save(commit=False)
            resource.uploaded_by = request.user
            resource.save()
            messages.success(request, 'Your resource is live. Thanks for contributing to UniVault.')
            return redirect('resources:resource_detail', pk=resource.pk)
    else:
        form = ResourceForm()
    return render(request, 'resources/resource_form.html', {'form': form, 'is_edit': False})


@login_required
def resource_update(request, pk):
    resource = get_object_or_404(Resource, pk=pk)
    if resource.uploaded_by != request.user:
        messages.error(request, "You can only edit resources you uploaded yourself.")
        return redirect('resources:resource_detail', pk=pk)

    if request.method == 'POST':
        form = ResourceForm(request.POST, request.FILES, instance=resource)
        if form.is_valid():
            form.save()
            messages.success(request, 'Resource updated.')
            return redirect('resources:resource_detail', pk=resource.pk)
    else:
        form = ResourceForm(instance=resource)

    return render(request, 'resources/resource_form.html', {'form': form, 'is_edit': True, 'resource': resource})


@login_required
def resource_delete(request, pk):
    resource = get_object_or_404(Resource, pk=pk)
    if resource.uploaded_by != request.user:
        messages.error(request, "You can only delete resources you uploaded yourself.")
        return redirect('resources:resource_detail', pk=pk)

    if request.method == 'POST':
        resource.delete()
        messages.success(request, 'Resource removed.')
        return redirect('resources:dashboard')

    return render(request, 'resources/resource_confirm_delete.html', {'resource': resource})


def resource_download(request, pk):
    resource = get_object_or_404(Resource, pk=pk)
    if not resource.file:
        raise Http404('This resource has no file attached.')

    Resource.objects.filter(pk=pk).update(download_count=resource.download_count + 1)
    try:
        return FileResponse(resource.file.open('rb'), as_attachment=True, filename=resource.file_name)
    except FileNotFoundError:
        raise Http404('That file could not be found on the server.')


@login_required
def toggle_bookmark(request, pk):
    resource = get_object_or_404(Resource, pk=pk)
    bookmark, created = Bookmark.objects.get_or_create(user=request.user, resource=resource)
    if not created:
        bookmark.delete()
        bookmarked = False
    else:
        bookmarked = True

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({'bookmarked': bookmarked})

    return redirect('resources:resource_detail', pk=pk)


@login_required
def add_rating(request, pk):
    resource = get_object_or_404(Resource, pk=pk)
    if request.method == 'POST':
        existing = Rating.objects.filter(resource=resource, user=request.user).first()
        form = RatingForm(request.POST, instance=existing)
        if form.is_valid():
            rating = form.save(commit=False)
            rating.resource = resource
            rating.user = request.user
            rating.save()
            messages.success(request, 'Thanks — your rating has been saved.')
        else:
            messages.error(request, 'Please choose a star rating.')
    return redirect('resources:resource_detail', pk=pk)


@login_required
def dashboard(request):
    my_resources = Resource.objects.filter(uploaded_by=request.user).select_related('category')
    my_bookmarks = Bookmark.objects.filter(user=request.user).select_related('resource', 'resource__category')
    total_downloads = sum(my_resources.values_list('download_count', flat=True))

    context = {
        'my_resources': my_resources,
        'my_bookmarks': my_bookmarks,
        'total_downloads': total_downloads,
    }
    return render(request, 'resources/dashboard.html', context)


def category_detail(request, slug):
    category = get_object_or_404(Category, slug=slug)
    resources = Resource.objects.filter(category=category).select_related('uploaded_by').order_by('-uploaded_at')
    paginator = Paginator(resources, RESOURCES_PER_PAGE)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'resources/category_detail.html', {'category': category, 'page_obj': page_obj})


def leaderboard(request):
    """
    'Extra feature': ranks students by how much they've contributed —
    number of resources shared and total downloads those resources have
    earned — to gamify contributing back to UniVault.
    """
    contributors = (
        User.objects.annotate(
            upload_count=Count('resources', distinct=True),
            total_downloads=Sum('resources__download_count'),
        )
        .filter(upload_count__gt=0)
        .order_by('-total_downloads', '-upload_count')[:20]
    )
    return render(request, 'resources/leaderboard.html', {'contributors': contributors})


def about(request):
    return render(request, 'resources/about.html')
